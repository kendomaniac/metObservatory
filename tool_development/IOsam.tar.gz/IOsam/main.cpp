


#ifndef __STDL__
	#define __STDL__
	#include <stdlib.h>
#endif

#ifndef __IOS_H__
	#define __IOS_H__
	#include <iostream>
#endif

#ifndef __BAM_H__
	#define __BAM_H__
    #include <seqan/bam_io.h>
#endif


using namespace seqan;
using namespace std;

int main(int argc, char **argv) {

clock_t startGlobal,endGlobal;
startGlobal=clock();

cout<<"\n\n =========================================================\n";
cout<<"|	      	          BAMandSAM      	          |\n";
cout<<"|	      	          Filtering    	                |\n";
cout<<" =========================================================\n";
cout<<"\n If you find any bug, send an email to beccuti@di.unito.it\n";

if ((argc<3)){
    std::cerr<<"\n\nUSE: BAMandSAM <path/InputFile> <path/OutputFile> \n\n\t File extension is used to choice between bam or sam \n\n";
    exit(EXIT_FAILURE);
}


// Open input BAM file, BamFileIn supports both SAM and BAM files.
BamFileIn bamFileIn;
if (!open(bamFileIn, argv[1])){
    std::cerr << "\n\nERROR: Could not open " << argv[1] << endl<<endl;
    exit(EXIT_FAILURE);
}

// Open output SAM file by passing the context of bamFileIn and the filename to open.
BamFileOut samFileOut(context(bamFileIn),argv[2]);

int num_read_read=0,num_read_sel=0;
try
    {
    BamHeader header;
    readHeader(header, bamFileIn);
    writeHeader(samFileOut, header);

        // Copy all records.
    BamAlignmentRecord record;

    while (!atEnd(bamFileIn))
    {
        readRecord(record, bamFileIn);
        if ( !hasFlagAllProper(record)){
            writeRecord(samFileOut, record);
            num_read_sel++;
            }
        if ((++num_read_read)%1000000==0)
            cout<<"#Read processed: "<<num_read_read<<" #Read selected: "<<num_read_sel<<endl;
    }
} catch (Exception const & e)
    {
        std::cout << "\n\n ERROR: " << e.what() << std::endl;
        exit(EXIT_FAILURE);
    }

 endGlobal=clock();
 cout<<"\nData saved in: "<<argv[2]<<endl;
 cout<<"Total reads: "<<num_read_read<<" total selected reads: "<<num_read_sel<<endl<<endl;

 cout<<"\n=========================== TIME ===========================\n\n";
 cout<<"\tTime to compute frequencies: "<<((double)(endGlobal-startGlobal))/CLOCKS_PER_SEC<<"s."<<endl;
 cout<<"\n============================================================\n\n";

}
